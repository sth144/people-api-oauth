# Google People API Oauth Flow
An example authorization flow for Google's People API.