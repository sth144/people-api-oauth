export interface IPersonInfo {
    firstname: string,
    lastname: string
    state?: string
}