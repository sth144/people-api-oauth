export interface IPersonInfo {
    firstname: string,
    lastname: string
}